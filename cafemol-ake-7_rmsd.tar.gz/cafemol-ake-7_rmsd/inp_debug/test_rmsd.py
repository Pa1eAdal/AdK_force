import numpy as np
import mdtraj as md

select = np.arange(214)
select = np.arange(90)
select = [12,35,87,122,155,166]

traj = md.load_dcd('ake_debug.dcd', top='../pdb/4ake_5unit0_CA.pdb')
ref = md.load('../pdb/1ake_5unit0_CA.pdb')
rmsd = md.rmsd(traj, ref, atom_indices=select)
print(select)
print(rmsd*10)
