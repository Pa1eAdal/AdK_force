import numpy as np
#from itertools import islice
import sys
import copy
import itertools

sys.path.append('../ninfo')
import nativeinfo as ninfo
sys.path.append('../gen_mutation_ninfo')
import sel_mutation_target as sel

bdsites=sel.get_bdsites()

#parain
fin='ake_aicg2plus.para'

seqinter=np.loadtxt(fin,usecols=[0],dtype=int)
Ns=np.argwhere(seqinter==1)
Ns=Ns.reshape(4)
ns=np.hstack((Ns,len(seqinter)))

iteminter='bd ba dih con'.split()

formatinter=["%10d"*2+"%10.3f",\
             "%10d"*2+"%10.3f"*2,\
             "%10d"*2+"%10.3f"*2,\
             "%10d"*3+"%10.3f"]
formats=dict(zip(iteminter,formatinter))

para={}
for n,i in enumerate(iteminter):
    para[i]=np.loadtxt(fin,skiprows=int(ns[n]),max_rows=int(ns[n+1])-int(ns[n]))

paracoefgo=para['con'][:,3]    

#genicon from ninfo 
#scale para
tagstart=1
mimplist=np.array("106 33 56 158 163".split(),dtype=int)
mimplist=[[106],[33],[56],[158],[163]]
#tagstart=6
#mimplist=[[33,56,158,163],[33,56,54,55],[158,163]]
mtags=np.arange(len(mimplist))+tagstart
mimpdict=dict(zip(mtags,mimplist))

ninfoname = '../ninfo/ake_wt.ninfo'
scale = [0.01,0.03,0.10,0.20,0.30]
scale_l1 = [1.0,0.5,0.8]
scale =[1.8]
scale_l1 = [1.5,1.2]

pdninfo = ninfo.openinfo(ninfoname)
for m,sc,sc_l1 in itertools.product(mtags,scale,scale_l1):
    #gen mutation icon list
    tmpninfo = copy.deepcopy(pdninfo)
    imp=np.array(mimpdict[m])
    impdummy=imp+214
    #print(m,imp,impdummy)
    ncount_open=0
    ncount_close=0

    ninfocons=[]
    for con in tmpninfo.data['contact']:
        if con['dummy']==0:
            continue
        ninfocons.append((con['icon'],con['imp1'],con['imp2'],con['coef_go']))
    dtype=[('icon',int),('imp1',int),('imp2',int),('coef_go',float)]
    tmparrcons=np.array(ninfocons,dtype=dtype)
    allcons=np.sort(tmparrcons,order=['imp1','imp2'])
    #allcons=np.sort(tmparrcons,order=['icon'])
    ninfocoefgo=allcons['coef_go'] #for debug
        

    ##select contacts
    ####### select center
    mcons=[]
    #for ncon,con in enumerate(tmparrcons):
    for ncon,con in enumerate(allcons):
        con['icon']=ncon+1
        if con['imp1'] in imp  or con['imp2'] in imp:
            mcons.append(con['icon'])
            print(con)
            ncount_open += 1
        if con['imp1'] in impdummy  or con['imp2'] in impdummy:
            mcons.append(con['icon'])
            print(con)
            ncount_close +=1
    
    mcons=np.array(mcons)
            
    print(ncount_open,ncount_close)
    print(mcons)
    print('\n')
    
    ####### select first layer
    impl1 = sel.get_mutation_layer1(imp)
    impl1dummy = impl1 + 214
    ml1cons=[]
    ncountl1_open, ncountl1_close = 0,0
    #for ncon,con in enumerate(tmparrcons):
    for ncon,con in enumerate(allcons):
        con['icon']=ncon+1
        if con['icon'] in mcons:
            continue
        if con['imp1'] in impl1  or con['imp2'] in impl1:
            ml1cons.append(con['icon'])
            print(con)
            ncountl1_open += 1
        if con['imp1'] in impl1dummy  or con['imp2'] in impl1dummy:
            ml1cons.append(con['icon'])
            print(con)
            ncountl1_close +=1
    
    ml1cons=np.array(ml1cons)
            
    print(ncountl1_open,ncountl1_close)
    print(ml1cons)
    print('\n')
    

    #scale para
    newpara=copy.deepcopy(para)
    string=formats['con']
    
    ######scale center
    for mcon in mcons:
        mc = mcon-1 
        #print(string%tuple(para['con'][mc]))
        newpara['con'][mc][3] *= sc
        #print(string%tuple(newpara['con'][mc]))
    
    #######scale first layer
    for ml1con in ml1cons:
        ml1c = ml1con-1 
        #print(string%tuple(para['con'][ml1c]))
        newpara['con'][ml1c][3] *= sc_l1
        #print(string%tuple(newpara['con'][ml1c]))
        
    #write newpara
    fout='_'.join(['ake_aicg2plus','m%d'%m,'%0.2f'%sc,'%0.2f'%sc_l1])+'.para'
    #print(fout)
    with open(fout,'w') as f:
        for i in iteminter:
            for l in newpara[i]:
                f.write(formats[i]%tuple(l)+'\n')


    for n,(a,b) in enumerate(zip(paracoefgo,ninfocoefgo)):
        if a != b:
            print(n+1,a,b)
