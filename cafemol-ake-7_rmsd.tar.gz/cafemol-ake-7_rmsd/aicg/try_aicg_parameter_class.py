# Python aicg1_parameter clss -- A python class for aicg1.para file in cafemol

name = 'ake_aicg2plus.para'

class para(object):
    def __init__(self):
        # self.data records all the para data.
        self.data = {'bd':[],'ba':[],'dih':[],'con':[]}
        self._nbd = 0
        self._nba = 0
        self._ndih = 0
        self._con = 0

    def _AddBd(self, bddict):
        self.bdkey = 'ibd iunit kbd'.split()
        for i in self.bdkey:
            if i not in list(bddict.keys()):
                return False
        self._nbd += 1
        bddict['ibd'] = self._nbond

