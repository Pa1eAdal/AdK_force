import sys
import numpy as np
#sys.path.append('/fsa/home/ww_wuyc/Documents/ninfo')
import nativeinfo as ninfo
import copy
import itertools

#mimplist=np.array('33 56 54 55 158 163'.split(),dtype=int)
tagstart=2
mimplist=np.array("33 56 158 163".split(),dtype=int)
mimplist=np.array("33".split(),dtype=int)
mtags=np.arange(len(mimplist))+tagstart
mimpdict=dict(zip(mtags,mimplist))

ninfoname = 'ake_wt.ninfo'
outhead = 'ake_m'
outtail = '.ninfo'
lbd_range = [1.0,0.9]
string = 'contact'+' %6d'*7+'%12.4f'*2+' %6d'+'%12.4f'+' %s\n'

def main():
    pdninfo = ninfo.openinfo(ninfoname)
    for m,lbd in itertools.product(mtags,lbd_range):
        tmpninfo = copy.deepcopy(pdninfo)
        outname = outhead+str(m)+'_%.2f'%lbd+outtail
        imp=mimpdict[m]
        impdummy=imp+214
        print(m,imp,impdummy)
        ncount=0
    
        for con in tmpninfo.data['contact']:
            if con['imp1'] == imp  or con['imp2'] == imp:
                OriginStrength = con['coef_go']
                con['coef_go'] = float(lbd)*OriginStrength
                con['factor_go'] = float(lbd)
                ncount = ncount + 1
                print(con.values())
    
            if con['imp1'] == impdummy  or con['imp2'] == impdummy:
                OriginStrength = con['coef_go']
                con['coef_go'] = float(lbd)*OriginStrength
                con['factor_go'] = float(lbd)
                ncount = ncount + 1
                print(con.values())
                
        tmpninfo.write(outname)
        print(ncount)
        print('\n')

if __name__ == '__main__':
    main()
