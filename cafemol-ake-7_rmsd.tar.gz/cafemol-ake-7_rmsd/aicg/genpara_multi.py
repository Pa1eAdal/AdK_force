import numpy as np
#from itertools import islice
import sys
sys.path.append('../ninfo')
import nativeinfo as ninfo
import copy
import itertools

#parain
fin='ake_aicg2plus.para'

seqinter=np.loadtxt(fin,usecols=[0],dtype=int)
Ns=np.argwhere(seqinter==1)
Ns=Ns.reshape(4)
ns=np.hstack((Ns,len(seqinter)))

iteminter='bd ba dih con'.split()

formatinter=["%10d"*2+"%10.3f",\
             "%10d"*2+"%10.3f"*2,\
             "%10d"*2+"%10.3f"*2,\
             "%10d"*3+"%10.3f"]
formats=dict(zip(iteminter,formatinter))

para={}
for n,i in enumerate(iteminter):
    para[i]=np.loadtxt(fin,skiprows=int(ns[n]),max_rows=int(ns[n+1])-int(ns[n]))

paracoefgo=para['con'][:,3]    

#genicon from ninfo 
#scale para
tagstart=6
mimplist=np.array("106 33 56 158 163".split(),dtype=int)
mimplist=[[33,56,158,163],[33,56,54,55],[158,163]]
mtags=np.arange(len(mimplist))+tagstart
mimpdict=dict(zip(mtags,mimplist))

ninfoname = '../ninfo/ake_wt.ninfo'
scale = [0.01,0.50]
scale = [0.10,0.20]
scale = [0.10,0.01]

pdninfo = ninfo.openinfo(ninfoname)
for m,sc in itertools.product(mtags,scale):
    #gen mutation icon list
    tmpninfo = copy.deepcopy(pdninfo)
    imp=np.array(mimpdict[m])
    impdummy=imp+214
    #print(m,imp,impdummy)
    ncount_open=0
    ncount_close=0

    ninfocons=[]
    for con in tmpninfo.data['contact']:
        if con['dummy']==0:
            continue
        ninfocons.append((con['icon'],con['imp1'],con['imp2'],con['coef_go']))
    dtype=[('icon',int),('imp1',int),('imp2',int),('coef_go',float)]
    tmparrcons=np.array(ninfocons,dtype=dtype)
    allcons=np.sort(tmparrcons,order=['imp1','imp2'])
    #allcons=np.sort(tmparrcons,order=['icon'])
    ninfocoefgo=allcons['coef_go']
        
    mcons=[]
    #for ncon,con in enumerate(tmparrcons):
    for ncon,con in enumerate(allcons):
        con['icon']=ncon+1
        if con['imp1'] in imp  or con['imp2'] in imp:
            mcons.append(con['icon'])
            print(con)
            ncount_open += 1
        if con['imp1'] in impdummy  or con['imp2'] in impdummy:
            mcons.append(con['icon'])
            print(con)
            ncount_close +=1
    
    mcons=np.array(mcons)
            
    print(ncount_open,ncount_close)
    print(mcons)
    print('\n')
    
    #scale para
    newpara=copy.deepcopy(para)
    string=formats['con']
    for mcon in mcons:
        mc = mcon-1 
        #print(string%tuple(para['con'][mc]))
        newpara['con'][mc][3] *= sc
        #print(string%tuple(newpara['con'][mc]))

    #write newpara
    fout='_'.join(['ake_aicg2plus','m%d'%m,'%0.2f'%sc])+'.para'
    #print(fout)
    with open(fout,'w') as f:
        for i in iteminter:
            for l in newpara[i]:
                f.write(formats[i]%tuple(l)+'\n')


    for n,(a,b) in enumerate(zip(paracoefgo,ninfocoefgo)):
        if a != b:
            print(n+1,a,b)
