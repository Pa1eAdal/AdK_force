# -*- coding: utf-8 -*-
"""
Created on Mon Aug 31 00:02:35 2020

@author: Yang
"""
"""
Mutiple Yaxis With Spines

Create multiple y axes with a shared x axis.
This is done by creating a #twinx axes,
turning all spines but the right one invisible
and offset its position using #set_position.
"""

import numpy as np
import matplotlib.pyplot as plt
import itertools

#from mpl_toolkits.axisartist.parasite_axes import HostAxes,ParasiteAxes
from matplotlib import rc
#plt.rcParams.items()

from palettable.tableau import Tableau_10

from matplotlib.lines import Line2D

rc('font',**{'style':'normal','size':8}) # 12
rc('axes',**{'titlesize':8})
rc('mathtext',**{'default':'regular'})
rc(('ytick'),**{'labelsize':6,'direction':'in','major.pad':1,'major.size':3})
rc(('xtick'),**{'labelsize':6,'direction':'in','major.pad':1,'major.size':3})
rc(('axes'),**{'labelsize':8,'labelpad':1,'linewidth':1}) # 10
rc(('legend'),**{'fontsize':6,'frameon':False,'labelspacing':0.5,'handletextpad':0.8}) # 8

cls=plt.rcParams['axes.prop_cycle'].by_key()['color']

my_dpi = 300
rect = [0.18,0.15,0.75,0.75]

pre7="0.41".split()
xkai="0.75 0.50".split()

scaleback = 120 

def func(x,kc,ki,km):
    return kc*x/((1/ki)*x*x+x+km)

shape1=(6.1/3,2)
shape2=(3,2)

for g,xk in itertools.product(pre7,xkai):
    
    fn='pclose_kcat_KI_KM_%s_%s_mutation_l1.dat' % (g,xk)
    #np.savetxt(fnfit,(plist,kcatlist,KIlist,KMlist),fmt='%.3f')

    #plot fit params
    pclose,kcat,kcaterr,KI,KIerr,KM,KMerr=np.loadtxt(fn) # 2000ADP/min = 1/60 turnover/ms
    kcat /= scaleback
    kcaterr /= scaleback
    
    # pclose = pclose[1:]
    # kcat = kcat[1:]
    # kcaterr = kcaterr[1:]
    # KI = KI[1:]
    # KIerr = KIerr[1:]
    # KM = KM[1:]
    # KMerr = KMerr[1:]
    
    # plot kcat
    fig = plt.figure(figsize=shape1,dpi=my_dpi)
    ax = fig.add_axes(rect)
    ax.set_xlabel('$P_{close}$')
    ax.set_ylabel('$k_{cat}$ ($ms^{-1}$)')
    c1,c2=0.0,0.8
    ax.set_ylim(c1,c2)
    ax.set_yticks(np.linspace(c1,c2,5))
    
    # ### linear
    # ax.set_xlim(-0.08,1.09)
    # ax.set_xticks([0.0,0.2,0.4,0.6,0.8,1.0])
    # ax.set_xticks([0.1,0.3,0.5,0.7],minor=True)
    # ax.set_xticklabels('0.0 0.2 0.4 0.6 0.8 1.0'.split())
    
    ### log
    ax.set_xscale('log')
    ax.set_xlim(0.077*10**(-0.2),1*10**(0.2))
    # ax.arrow(0.15,c1+0.05,dx=0.05,dy=0,lw=0.5,head_width=0.01,head_length=0.05,color='k')
    # ax.text(0.08,c1+0.042,'WT',fontsize=6)
    # dot = ax.plot(0.283,68.6/scaleback*0.8,'o',color=cls[0],ms=4,zorder=0)
    
    ax.vlines(x=0.283,ymin=0,ymax=1000,linestyle='--',color="grey",lw=1.0)
    line = ax.errorbar(pclose,kcat,kcaterr,color='k',capsize=2,lw=1.0)
  
    fig.text(0.0,0.91,'D',fontsize=16)
    fig.savefig('kcat_%s_%s_mutation_l1.png' % (g,xk))
    # fig.savefig('../../Figures/kcat_%s_%s_mutation_l1.pdf' % (g,xk))
    
    # plot KM
    fig = plt.figure(figsize=shape1,dpi=my_dpi)
    ax = fig.add_axes(rect)
    ax.set_xlabel('$P_{close}$')
    ax.set_ylabel('$K_M$ ($\mu M$)')
    m1,m2=0,200
    ax.set_ylim(m1,m2)
    ax.set_yticks(np.linspace(m1,m2,5))
    
    # ### linear
    # ax.set_xlim(-0.08,1.09)
    # ax.set_xticks([0.0,0.2,0.4,0.6,0.8,1.0])
    # ax.set_xticks([0.1,0.3,0.5,0.7],minor=True)
    # ax.set_xticklabels('0.0 0.2 0.4 0.6 0.8 1.0'.split())
    
    ### log
    ax.set_xscale('log')
    ax.set_xlim(0.077*10**(-0.2),1*10**(0.2))
    # ax.arrow(0.15,m1+(m2-m1)*0.1,dx=0.05,dy=0,head_width=5,head_length=0.05,color='k')
    # ax.text(0.08,m1+(m2-m1)*0.1,'WT',fontsize=6)
    # dot = ax.plot(0.283,46.8,'o',color=cls[1],ms=4,zorder=0)
    
    ax.vlines(x=0.283,ymin=0,ymax=1000,linestyle='--',color="grey",lw=1.0)
    line = ax.errorbar(pclose,KM,KMerr,color='k',capsize=2,lw=1.0)
  
    fig.text(0.0,0.91,'E',fontsize=16)
    fig.savefig('KM_%s_%s.dat.png' % (g,xk))
    # fig.savefig('../../Figures/KM_%s_%s.dat.pdf' % (g,xk) )
    
    
    # plot KI
    fig = plt.figure(figsize=shape1,dpi=my_dpi)
    ax = fig.add_axes(rect)
    ax.set_xlabel('$P_{close}$')
    ax.set_ylabel('$K_I$ ($mM$)')
    i1,i2=0/1000,3200/1000
    ax.set_ylim(i1,i2)
    ax.set_yticks(np.linspace(i1,i2,5))
    
    # ### linear
    # ax.set_xlim(-0.08,1.09)
    # ax.set_xticks([0.0,0.2,0.4,0.6,0.8,1.0])
    # ax.set_xticks([0.1,0.3,0.5,0.7],minor=True)
    # ax.set_xticklabels('0.0 0.2 0.4 0.6 0.8 1.0'.split())
    
    ### log
    ax.set_xscale('log')
    ax.set_xlim(0.077*10**(-0.2),1*10**(0.2))
    # ax.arrow(0.15,c1+(c2-c1)*0.1,dx=0.05,dy=0,head_width=5,head_length=0.05,color='k')
    # ax.text(0.08,c1+(c2-c1)*0.1,'WT',fontsize=6)
    # dot = ax.plot(0.283,930.5/100,'o',color=cls[2],ms=4,zorder=0)
    
    ax.vlines(x=0.283,ymin=0,ymax=4000,linestyle='--',color="grey",lw=1.0)
    line = ax.errorbar(pclose,KI/1000,KIerr/1000,color='k',capsize=2,lw=1.0)
  
    fig.text(0.0,0.91,'F',fontsize=16)
    fig.savefig('KI_%s_%s_mutation_l1.png' % (g,xk))
    # fig.savefig('../../Figures/KI_%s_%s_mutation_l1.pdf' % (g,xk))


    # plot turnover fit and legend
    pselect = np.array([0.283,0.077,0.088,0.169,0.434,0.595,0.633])
    pselect1 = np.array([0.283,0.077,0.633])
    
    
    #plot turnover_fit
    pselect = np.array([0.283,0.077,0.633,0.088,0.169,0.434,0.595])
    pselect1 = np.array([0.283,0.077,0.633])
    
    pselect = np.array([0.283,0.088,0.633,0.169,0.434,0.595])
    pselect1 = np.array([0.283,0.088,0.633])
     
    colors = ['k','r','b','pink','wheat','palegreen','paleturquoise']
    colors = ['k','r','b','wheat','palegreen','paleturquoise']
    colordict = dict(zip(pselect,colors))
      
    fign='fit_turnover_rate_%s_%s_hotcold_mutation_l1.png' % (g,xk)
    fig = plt.figure(figsize=(2,2),dpi=my_dpi)
    ax = fig.add_axes([0.18,0.15,0.75,0.75])
    ax.set_xlim(0,1050)
    ax.set_ylim(-0.12,0.5)
    # ax.set_ylim(0,0.45)
    ax.set_yticks(np.arange(0, 0.5,0.1))
    ax.set_xlabel('AMP $(\mu M)$')
    ax.set_ylabel('Turnover rate ($ms^{\u2010 1}$)')

    xfit = np.linspace(0,1000,100)
    yfit = func(xfit,68.6/scaleback,930.5,46.8)
    # ax.plot(xfit,yfit,'--',color='k',lw=1)
    for p in pselect:
        alpha = 0.8
        zorder = 2
        label = '%.2f' % p
        if p in pselect1:
            alpha = 1.0
            zorder = 3
        if p==0.283:
            label = ''
        datan='xy_%.3f_%s_%s_mutation_l1.dat' % (p,g,xk)
        x,y = np.loadtxt(datan)
        y /= 60
        index = list(pclose).index(p)
        kc = kcat[index]
        ki = KI[index]
        km = KM[index]
        yfit=func(xfit,kc,ki,km)
        ax.plot(x,y,'o',ms=4,mew=0,alpha=alpha,color=colordict[p],zorder=zorder,label=label)
        ax.plot(xfit,yfit,color=ax.lines[-1].get_color(),alpha=alpha,lw=1)

    prop = dict(arrowstyle="-|>,head_width=0.1,head_length=0.6",
            shrinkA=0,shrinkB=0,facecolor='k',lw=1)    
    ax.annotate('',xy=(520+150,0.29+0.05+0.1),xytext=(520,0.29),arrowprops=prop)
    ax.text(670,0.32+0.1,'WT\n$P_{close}=0.28$',fontsize=6)


    ax.legend(loc='lower center',ncol=3,fontsize=5.5,handletextpad=-0.4,markerscale=0.8)
    fig.text(0.0,0.91,'C',fontsize=16)
    fig.savefig(fign)    
    # fig.savefig('../../Figures/fit_turnover_rate_%s_%s_hotcold_mutation_l1.pdf' % (g,xk))
    
    
    
    
    
    
    
    # c1,c2=0,80
    # i1,i2=200,3400
    # m1,m2=0,800
    # host.set_ylim(c1,c2)
    # par1.set_ylim(i1,i2)
    # par2.set_ylim(m1,m2)

    # host.set_yticks(np.linspace(c1,c2,5))
    # par1.set_yticks(np.linspace(i1,i2,5))
    # par2.set_yticks(np.linspace(m1,m2,5))

    # ### linear
    # host.set_xlim(-0.08,1.08)
    # host.set_xticks([0.0,0.2,0.4,0.6,0.8,1.0])
    # host.set_xticks([0.1,0.3,0.5,0.7],minor=True)
    # host.set_xticklabels('0.0 0.2 0.4 0.6 0.8 1.0'.split())
    
    # ### log
    # host.set_xscale('log')
    # host.set_xlim(0.003*10**(-0.08),1*10**(0.08))

    # host.vlines(x=0.283,ymin=0,ymax=1000,linestyle='--',color="grey")

    # p1=host.errorbar(pclose,kcat,kcaterr,color=cls[0],capsize=4)
    # p2=par1.errorbar(pclose,KI,yerr=KIerr,color=cls[1],capsize=4)
    # p3=par2.errorbar(pclose,KM,yerr=KMerr,color=cls[2],capsize=4)

    # dot1,=host.plot(0.283,68.6,'o',color=cls[0])
    # dot2,=par1.plot(0.283,930.5,'o',color=cls[1])
    # dot3,=par2.plot(0.283,46.8,'o',color=cls[2])

    # p1,=host.plot(pclose,kcat,color=cls[0],label=r'$k_{cat}$')
    # p2,=par1.plot(pclose,KI,color=cls[1],label='KI')
    # p3,=par2.plot(pclose,KM,color=cls[2],label='KM')

    # host.yaxis.label.set_color(p1.get_color())
    # par1.yaxis.label.set_color(p2.get_color())
    # par2.yaxis.label.set_color(p3.get_color())

    # tkw=dict(size=2,width=1.0)
    # host.tick_params(axis='y',colors=p1.get_color(),**tkw)
    # par1.tick_params(axis='y',colors=p2.get_color(),**tkw)
    # par2.tick_params(axis='y',colors=p3.get_color(),**tkw)
    # host.tick_params(axis='x',**tkw)

    # lines=[p1,p2,p3]
    # host.legend(lines,[l.get_label() for l in lines],ncol=3,\
    #             loc='upper center',\
    #             columnspacing=1.0,handletextpad=None,markerscale=0.8)

    # plt.show()

    # fig.savefig(fign)

