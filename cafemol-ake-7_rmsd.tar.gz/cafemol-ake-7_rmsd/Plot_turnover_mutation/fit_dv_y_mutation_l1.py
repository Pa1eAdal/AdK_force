# -*- coding:  utf-8 -*-
"""
Created on Sun Aug 30 02: 45: 53 2020

@author:  Yang
"""


# kcat/y = (1/KI)*x+KM*(1/x)+1
import numpy as np
import itertools
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

from matplotlib import rc
# plt.rcParams.items()
rc('font', **{'style': 'normal', 'size': 8})
# rc('lines', **{'markersize': 4})
rc('axes', **{'titlesize': 8})
rc('mathtext', **{'default': 'regular'})
rc(('xtick', 'ytick'), **{'labelsize': 6, 'direction': 'in', 'major.pad': 1})
rc(('axes'), **{'labelsize': 8, 'labelpad': 0, 'linewidth': 1})
rc(('legend'), **{'fontsize': 4.5, 'markerscale': 2.0, 'handlelength': 3.0, 'frameon': False})

my_dpi = 300
rect = [0.10, 0.10, 0.5, 0.8]


def func(x, kc, ki, km): 
    return kc*x/((1/ki)*x*x+x+km)


pcloselist = "0.077 0.088 0.169 0.283 0.434 0.595 0.633".split()
pcloselist = "0.077 0.169 0.283 0.434 0.595".split()
pre7 = "0.41".split()
rmsdlist = "0.6".split()

scale = 2.0

for g, rmsd in itertools.product(pre7, rmsdlist): 
    fntail = '%s_%s_mutation_l1' % (g, rmsd)
    fig = plt.figure(figsize=(4, 2), dpi=my_dpi)
    ax = fig.add_axes(rect)
    ax.set_title(r'$MT\ AMP\ SI\ pre7 = $'+g)
    ax.set_title('$rmsd_{cata}$'+'_cut=%s'%rmsd)
    ax.set_xlabel(r'$[AMP](\mu M)$')
    ax.set_ylabel(r'$\mu M\ of\ ADP/min/nM\ Adk$')
    kcatlist = []
    kcaterr = []
    KIlist = []
    KIerr = []
    KMlist = []
    KMerr = []

    for n, pclose in enumerate(pcloselist): 
        fn = 'xy_%s_%s.dat' % (pclose,fntail)
        # x, y, yerr = np.loadtxt(fn)
        x, y = np.loadtxt(fn)
        print(x)
        y *= scale

        p0 = (50, 1000, 70)
        # trick x = [0, 9, 22, 44, 66, 100, 150, 200, 250, 300, 400, 500, 750, 1000]
        # trick = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
        (kcat, KI, KM), pcov = curve_fit(func, x, y, p0)

        kcatlist.append(kcat)
        KIlist.append(KI)
        KMlist.append(KM)
        kcaterr.append(pcov[0, 0]**0.5)
        KIerr.append(pcov[1, 1]**0.5)
        KMerr.append(pcov[2, 2]**0.5)

        xfit = np.linspace(0, 1000, 100)
        yfit = func(xfit, kcat, KI, KM)
        # label = 'pclose = '+pclose+', \n'\
        # '$kcat = %4.0f/min, K_I = %4.0f\mu M, K_M = %4.0f\mu M$'%(kcat, KI, KM)
        label = 'pclose = '+pclose+', \n'\
                '$kcat = %4.0f, K_I = %4.0f, K_M = %4.0f$' % (kcat, KI, KM)
        ax.plot(x, y, 'o')
        ax.plot(xfit, yfit, '-', color=ax.lines[-1].get_color(), label=label)

    # labelref = 'WT exp ref, \n'+\
    # '$kcat = %4.0f/min, K_I = %4.0f\mu M, K_M = %4.0f\mu M$'%(68.6, 930.5, 46.8)
    labelref = 'WT exp ref, \n' + \
               '$kcat = %4.0f, K_I = %4.0f, K_M = %4.0f$' % (68.6, 930.5, 46.8)
    ax.plot(xfit, func(xfit, 68.6, 930.5, 46.8), '--', color='black', label=labelref)

    ax.legend(bbox_to_anchor=(1.0, 1.0), loc='upper left')
    plt.show()
    fign = 'fit_%s.png' % (fntail)
    fig.savefig(fign)

    # output fitdata: pclose, kcat, KI, KM
    fnfit = '_'.join(['pclose_kcat_KI_KM', fntail])+'.dat'
    print(fnfit)
    plist = [float(i) for i in pcloselist]
    np.savetxt(fnfit, (plist, kcatlist, kcaterr, KIlist, KIerr, KMlist, KMerr), fmt='%.3f')
    

    fhuman = open('fit_h_%s.dat' % fntail, 'w')
    fhuman.write("%6s" % 'pclose')
    for a in plist: 
        fhuman.write("%13.2f" % a)
    fhuman.write("\n")

    fhuman.write("%6s" % 'kcat')
    for a, b in zip(kcatlist, kcaterr): 
        fhuman.write("%8.0f" % a+u"\u00B1"+"%4.0f" % b)
    fhuman.write("\n")

    fhuman.write("%6s" % 'KI')
    for a, b in zip(KIlist, KIerr): 
        fhuman.write("%8.0f" % a+u"\u00B1"+"%4.0f" % b)
    fhuman.write("\n")

    fhuman.write("%6s" % 'KM')
    for a, b in zip(KMlist, KMerr): 
        fhuman.write("%8.0f" % a+u"\u00B1"+"%4.0f" % b)

