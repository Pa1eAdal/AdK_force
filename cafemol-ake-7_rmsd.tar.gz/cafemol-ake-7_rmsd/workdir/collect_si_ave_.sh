#!/bin/bash

#substrate inhibition of amp: si_atpxamp
#turnover_t[atp]_0.16.dat

atpconc="1000"
ampconc="9 22 44 66 100 150 200 250 300 400 500 600 700 750 800 900 1000 1500 2000 2500 3000"
ampconc="9 22 44 66 100 150 200 250 300 400 500 750 1000"
ampconc="9 22 44 66 100 150 200 250 300 400 500 750 1000 1500 2000 2500 3000"
ampconc="9 22 44 66 100 150 200 250 300 400 500 600 700 800 900 1000"
#dv
dvlist="15 16 10 0 1 2 14"
#pre7=g
pre7list="0.41"

for dv in 0
do
for pre7 in $pre7list
do
# for rmsd in 1.0 0.9 0.8
for rmsd in 0.6
do
for conct in $atpconc
do
    atpn=`printf "%04d" $conct`

    fn=turnover_dv${dv}_g${pre7}_r${rmsd}.dat
    echo "# ampconc turnover1 turnover2 turnover3 pclosed" > $fn

    for concm in $ampconc
    do
        
        ampn=`printf "%04d" $concm`
        dirwork=dv${dv}_g${pre7}_r${rmsd}/t${atpn}_m${ampn}
        echo $dirwork
        
        tmp=`cat ${dirwork}/p_efficiency_ave.dat | awk '{printf("%f %f %f" ,$4,$5,$6)}'`
        pclosed=`cat ${dirwork}/population.dat | awk '{print $5}'`
        echo $ampn $tmp $pclosed >> $fn
    done
done
done
done
done
