# -*- coding: utf-8 -*-
"""
Created on Mon Aug  3 02:04:06 2020

@author: Yang
"""

import numpy as np
import itertools

dirdata='../workdir/turnover_ave/'
# valist=( -5.1 -5.7 -6.3 -4.7 -4.2 -3.8 -3.4 -3.1 -6.9  -7.5 -4.6 -4.5 -4.4  -8.1  -9.7)
# vblist=( -7.9 -8.5 -9.1 -7.3 -6.6 -5.9 -5.3 -4.8 -9.7 -10.3 -7.2 -7.1 -7.0 -10.9 -11.5)
# vclist=( -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0  -5.0 -5.0 -5.0 -5.0  -5.0  -5.0)
# dvnlist=(   0    1    2    3    4    5    6    7    8     9   10   11   12    13    14)
# pclose=( 0.30 0.52 0.77 0.15 0.05 0.02 9e-3 3e-3 0.89  0.94 0.12 0.10 0.09 0.986 0.997)
#dvlist="7 10 0 1 2 14".split()
#pcloselist="0.003 0.12 0.30 0.55 0.77 0.997".split()



dvlist="0".split()
pcloselist="0.283".split()
pre7="0.41".split()
xkai="0.75 0.50".split()
#mutation_type and scale_contact
mt="5 3 1".split()
sclist="0.20 1.80".split() #half is err with only 160 but not 320 scaled
sc1list="0.50 1.50".split()

atpconc="1000".split()
tscale = 112/(2e5)
tscalefit = tscale/60


for t,g,(n,pclose),m,sc,sc1 in itertools.product(atpconc,pre7,enumerate(pcloselist),mt,sclist,sc1list):
    print(t,g,n,pclose,m,sc,sc1)

dvn,mtn,scn,sc1n,pclosemn = np.loadtxt('./'+'pclose-dv-mutation-l1.dat',comments='#',usecols=(0,4,5,6,9),unpack=True)
dvn=np.array([ str(int(i)) for i in dvn])
mtn=np.array([ str(int(i)) for i in mtn])
scn=np.array([ '%.2f'%i for i in scn])
sc1n=np.array([ '%.2f'%i for i in sc1n])
# main
# def main():
for t in atpconc:
    for g,xk in itertools.product(pre7,xkai):
        for n,pclose in enumerate(pcloselist):
            dv=dvlist[n]
            for m,(sc,sc1) in itertools.product(mt,zip(sclist,sc1list)):
                fn=dirdata+'turnover_dv%s_m%s_sc%s_%s_x%s.dat' % (dv,m,sc,sc1,xk)
                try:
                    data=np.loadtxt(fn,comments="# @".split())
                except:
                    print("ADD_CALC"+fn)
                    continue
                x=data[:,0]
                x=np.array([0]+list(x))
                tmpa=np.zeros(1)
                tmpb=data[:,3]*0.5
                tmp=np.concatenate((tmpa,tmpb))
                y=tmp/tscale
                yout=tmp/tscalefit
                pc3=data[:,4]

                pclosem = pclosemn[np.isin(dvn,dvlist[n]) * np.isin(mtn,m) * np.isin(scn,sc) * np.isin(sc1n,sc1)]
                if len(pclosem)==0:
                    continue
                print(m,sc,sc1,pclosem)

                # turnover_ms vs ampconc 
                np.savetxt('turnover_%.3f_%s_%s_mutation_l1.dat' % (pclosem,g,xk), (x,y), fmt='%.8f')
                # V vs ampconc
                np.savetxt('xy_%.3f_%s_%s_mutation_l1.dat' % (pclosem,g,xk), (x,yout), fmt='%.8f')
                # pc3 vs ampconc
                # ADD_CALC : ampconc=0 
                np.savetxt('pc3_%.3f_%s_%s_mutation_l1.dat' % (pclosem,g,xk),(x[1:],pc3), fmt='%.8f')


# # start
# if __name__ == "__main__":
#     main()
