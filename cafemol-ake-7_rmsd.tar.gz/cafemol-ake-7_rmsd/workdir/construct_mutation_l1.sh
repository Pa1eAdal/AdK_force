#!/bin/bash

batch=19 #seq 0 19

atpconc="1000"
#ampconc="0 9 22 44 100 150 200 250 300 400 500 1000"
#ampconc="9 22 44"
ampconc="9 22 44 66 100 150 200 250 300 400 500 600 700 800 900 1000"

#dv
dv=VVVV
#pre7=g
pre7=GGGG
#mutation
m=MMMM
sc=SCSC
scl1=L1L1
rmsd=RRRR

for conct in $atpconc
do
    for concm in $ampconc
    do
        tmpt=`echo "scale=6;$conct*0.00635/300"|bc`
        tmpm=`echo "scale=6;$concm*0.00635/300"|bc`
        brt=`printf "%1.6f" $tmpt`
        brm=`printf "%1.6f" $tmpm`
        concnt=`printf "%04d" $conct`
        concnm=`printf "%04d" $concm`
        #echo atp $conct $brt $concnt 
        echo amp $concm $brm $concnm 

        dirdata=../../../data/dv${dv}_m${m}_sc${sc}_${scl1}_r${rmsd}/t${concnt}_m${concnm}
        dirwork=t${concnt}_m${concnm}
        mkdir -p $dirwork
        
        rm ${dirwork}/tsfilelist ${dirwork}/data0filelist

        for n in `seq -f "%03g" 0 $batch`
        do
            echo \'${dirdata}/ake_t${concnt}_m${concnm}_n${n}.ts\' >> ${dirwork}/tsfilelist
            echo 0data${n}.dat >> ${dirwork}/data0filelist
        done
    done
done
