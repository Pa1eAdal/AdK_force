#!/bin/bash

WKDIR=`pwd`

conc="0009 0022 0044 0066 0100 0150 0200 0250 0300 0400 0500 0600 0700 0800 0900 1000"

for c in $conc
do
    i=t1000_m$c
    cp run.lsf $i
    cd $i
pwd
read

../../../bin/ake_ts2data_s7_rmsd.o 
../../../bin/ake_efficiency_rmsd.o 
mv p_efficiency.dat p_efficiency_ave.dat

#for n in `seq -f "%03g" 0 19`
#do
#    echo 0data${n}.dat > data0filelist
#    ../../../bin/ake_turnover_rmsd.o 
#    mv p_efficiency.dat p_efficiency_${n}.dat
#done

    cd $WKDIR
done
