#!/bin/bash

#substrate inhibition of amp: si_atpxamp
#turnover_t[atp]_0.16.dat

atpconc="1000"
ampconc="9 22 44 66 100 150 200 250 300 400 500 750 1000"
ampconc="9 22 44 66 100 150 200 250 300 400 500 600 700 800 900 1000"
#dv
dvlist="0"
#pre7=g
pre7list="0.41"
#mutation

for dv in 0
do
  for pre7 in 0.41
  do
    # for rmsd in 0.8 0.6
    for rmsd in 1.0
    do
      for m in 5 1 
      do
        for sc in 0.20
        # for sc in 1.80
        do
          for sc1 in 0.50
          # for sc1 in 1.50
          do
            for conct in $atpconc
            do
              atpn=`printf "%04d" $conct`

              fn=turnover_dv${dv}_m${m}_sc${sc}_${sc1}_r${rmsd}.dat
              echo "# ampconc turnover1 turnover2 turnover3 pclosed" > $fn

              for concm in $ampconc
              do
            
                ampn=`printf "%04d" $concm`
                dirwork=dv${dv}_m${m}_sc${sc}_${sc1}_r${rmsd}/t${atpn}_m${ampn}
                echo $dirwork
            
                tmp=`cat ${dirwork}/p_efficiency_ave.dat | awk '{printf("%f %f %f" ,$4,$5,$6)}'`
                pclosed=`cat ${dirwork}/population.dat | awk '{print $5}'`
                echo $ampn $tmp $pclosed >> $fn
              done
            done
          done
        done
      done
    done
  done
done

for dv in 0
do
  for pre7 in 0.41
  do
    # for rmsd in 0.8  0.6
    for rmsd in 1.0
    do
      for m in 5 1 
      do
        # for sc in 0.20
        for sc in 1.80
        do
          # for sc1 in 0.50
          for sc1 in 1.50
          do
            for conct in $atpconc
            do
              atpn=`printf "%04d" $conct`

              fn=turnover_dv${dv}_m${m}_sc${sc}_${sc1}_r${rmsd}.dat
              echo "# ampconc turnover1 turnover2 turnover3 pclosed" > $fn

              for concm in $ampconc
              do
            
                ampn=`printf "%04d" $concm`
                dirwork=dv${dv}_m${m}_sc${sc}_${sc1}_r${rmsd}/t${atpn}_m${ampn}
                echo $dirwork
            
                tmp=`cat ${dirwork}/p_efficiency_ave.dat | awk '{printf("%f %f %f" ,$4,$5,$6)}'`
                pclosed=`cat ${dirwork}/population.dat | awk '{print $5}'`
                echo $ampn $tmp $pclosed >> $fn
              done
            done
          done
        done
      done
    done
  done
done
