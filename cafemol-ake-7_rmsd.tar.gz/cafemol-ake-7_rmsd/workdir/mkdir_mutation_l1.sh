#!/bin/bash
valist=( -5.1 -5.7 -6.3 -4.7 -4.2 -3.8 -3.4 -3.1 -6.9  -7.5 -4.6 -4.5 -4.4)
vblist=( -7.9 -8.5 -9.1 -7.3 -6.6 -5.9 -5.3 -4.8 -9.7 -10.3 -7.2 -7.1 -7.0)
vclist=( -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0  -5.0 -5.0 -5.0 -5.0)
dvnlist=(   0    1    2    3    4    5    6    7    8     9   10   11   12)
pclose=( 0.30 0.52 0.77 0.15 0.05 0.02 9e-3 3e-3 0.89  0.94)

for i in 0
do 
  for m in 5  1 
  do
    # for sc in 0.20
    for sc in 1.80
    do
        # for scl1 in 0.50
        for scl1 in 1.50
        do
          a=${valist[$i]}
          b=${vblist[$i]}
          c=${vclist[$i]}
          p=${pclose[$i]}
          
          echo $i $p $a $b $c m$m ${sc} ${scl1}
    
          for g in 0.41
          do
            # for rmsd in 0.8 0.6
            for rmsd in 1.0
            do
              dirwork=dv${i}_m${m}_sc${sc}_${scl1}_r${rmsd}
              echo $dirwork
              read
              mkdir $dirwork
          
# 1.gen README    
cat > ${dirwork}/README << DAT
dv=$i
pclose=$p

va=$a
vb=$b
vc=$c

pre7=$g
rmsd=$rmsd

mt=$m
sc=$sc
scl1=$scl1
DAT

# 2.construct_mutation.sh
              cp run.sh run.lsf bsub_run.sh construct_mutation_l1.sh ${dirwork}
              sed -i "s/GGGG/$g/g" ${dirwork}/construct_mutation_l1.sh
              sed -i "s/RRRR/${rmsd}/g" ${dirwork}/construct_mutation_l1.sh
              sed -i "s/VVVV/$i/g" ${dirwork}/construct_mutation_l1.sh
              sed -i "s/MMMM/$m/g" ${dirwork}/construct_mutation_l1.sh
              sed -i "s/SCSC/${sc}/g" ${dirwork}/construct_mutation_l1.sh
              sed -i "s/L1L1/${scl1}/g" ${dirwork}/construct_mutation_l1.sh
              chmod +x ${dirwork}/construct_mutation_l1.sh
              chmod +x ${dirwork}/bsub_run.sh
          done
        done
      done 
    done
  done  
done
