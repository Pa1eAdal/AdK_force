#!/bin/bash
valist=( -5.1 -5.7 -6.3 -4.7 -4.2 -3.8 -3.4 -3.1 -6.9  -7.5 -4.6 -4.5 -4.4)
vblist=( -7.9 -8.5 -9.1 -7.3 -6.6 -5.9 -5.3 -4.8 -9.7 -10.3 -7.2 -7.1 -7.0)
vclist=( -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0  -5.0 -5.0 -5.0 -5.0)
dvnlist=(   0    1    2    3    4    5    6    7    8     9   10   11   12)
pclose=( 0.30 0.52 0.77 0.15 0.05 0.02 9e-3 3e-3 0.89  0.94)

valist=(  -5.1  -5.7  -6.3  -4.5  -3.9  -3.3  -2.7  -3.1  -6.9   -7.5  -4.6  -4.5  -4.4   -8.1   -9.7  -3.8  -3.4)
vblist=(  -7.9  -8.5  -9.1  -7.3  -6.7  -6.1  -5.5  -4.8  -9.7  -10.3  -7.2  -7.1  -7.0  -10.9  -11.5  -5.9  -5.3)
vclist=(  -5.0  -5.0  -5.0  -5.0  -5.0  -5.0  -5.0  -5.0  -5.0   -5.0  -5.0  -5.0  -5.0   -5.0   -5.0  -5.0  -5.0)
dvnlist=(    0     1     2     3     4     5     6     7     8      9    10    11    12     13     14    15    16)
pclose=( 0.283 0.581 0.775 0.122 0.425 0.016   new 0.003 0.901  0.954 0.119   new   new    new  0.994 0.019 0.008)

#pre7
pre7="0.41"
# rmsdlist="1.0 0.9 0.8"
rmsdlist="0.6"

for i in 0
do 
    a=${valist[$i]}
    b=${vblist[$i]}
    c=${vclist[$i]}
    p=${pclose[$i]}
    for g in $pre7
    do
        for rmsd in $rmsdlist
        do
    echo $i $p $a $b $c $g $rmsd
    dirwork=dv${i}_g${g}_r${rmsd}
    mkdir $dirwork
    
# 1.gen README    
cat > ${dirwork}/README << DAT
dv=$i
pclose=$p

va=$a
vb=$b
vc=$c

pre7=$g
rmsd=$rmsd
DAT

# 2.construct.sh
   cp bsub_run.sh run.lsf ${dirwork}
    cp bsub_run.sh run.lsf construct.sh ${dirwork}
    sed -i "s/GGGG/$g/g" ${dirwork}/construct.sh
    sed -i "s/RRRR/${rmsd}/g" ${dirwork}/construct.sh
    sed -i "s/VVVV/$i/g" ${dirwork}/construct.sh
    chmod +x ${dirwork}/construct.sh
    chmod +x ${dirwork}/bsub_run.sh
    
    done
done
    
done
