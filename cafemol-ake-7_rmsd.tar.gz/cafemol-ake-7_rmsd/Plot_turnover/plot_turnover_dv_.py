# -*- coding: utf-8 -*-
"""
Created on Mon Aug  3 02:04:06 2020

@author: Yang
"""

import numpy as np
import itertools
import matplotlib.pyplot as plt
from matplotlib import rc

#plt.rcParams.items()
rc('font',**{'style':'normal','size':8})
rc('axes',**{'titlesize':8})
rc('mathtext',**{'default':'regular'})
rc(('xtick','ytick'),**{'labelsize':6,'direction':'in','major.pad':1})
rc(('axes'),**{'labelsize':8,'labelpad':0,'linewidth':1})
rc(('legend'),**{'fontsize':6,'frameon':False})

my_dpi=300
rect=[0.10,0.10,0.5,0.8]

# valist=( -5.1 -5.7 -6.3 -4.7 -4.2 -3.8 -3.4 -3.1 -6.9  -7.5 -4.6 -4.5 -4.4  -8.1  -9.7)
# vblist=( -7.9 -8.5 -9.1 -7.3 -6.6 -5.9 -5.3 -4.8 -9.7 -10.3 -7.2 -7.1 -7.0 -10.9 -11.5)
# vclist=( -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0  -5.0 -5.0 -5.0 -5.0  -5.0  -5.0)
# dvnlist=(   0    1    2    3    4    5    6    7    8     9   10   11   12    13    14)
# pclose=( 0.30 0.52 0.77 0.15 0.05 0.02 9e-3 3e-3 0.89  0.94 0.12 0.10 0.09 0.986 0.997)
dvlist="0 7 6 5 10 1 2 14".split()
pcloselist="0.283 0.003 0.008 0.019 0.119 0.581 0.775 0.994".split()
# dvlist,pcloselist=np.loadtxt('../workdir/pclose-dv.dat',comments='#',usecols=(0,6),unpack=True)
xkai="0.50".split()
pre7="0.41".split()
atpconc='1000'.split()

for t in atpconc:
    for g in pre7:
        fign='_'.join(['turnover','g'+g,'t'+t])+'.png'
        fig=plt.figure(figsize=(4,2),dpi=my_dpi)
        ax=fig.add_axes(rect)
        ax.set_title(r'$Turnover\ rate\ pre7=$'+g)
        ax.set_xlabel(r'$[AMP](\mu M)$')
        ax.set_ylabel(r'$turnover\ rate\ (ms^-1)$')

        for (n,pclose),xk in itertools.product(enumerate(pcloselist),xkai):
            fn='_'.join(['turnover',pclose,g,xk])+'.dat'
            data=np.loadtxt(fn,comments="# @".split())
            x,y=data

            #ax.plot(x,y,'o-',label=r'$[AMP]=%.0f(\mu M)$'%atp)
            ax.plot(x,y,'o-',label='pclose='+pclose)
            #ax.errorbar(x,y,yerr,color=ax.lines[-1].get_color(),capsize=4)


    ax.legend(bbox_to_anchor=(1.0,0.5),loc='center left')
    plt.show()
    fig.savefig(fign,dpi=my_dpi)

####plot_pclose


#
##ax2=ax.twinx()
##ax2.set_ylabel(r'$P_{closed}$')
#for g in pre7:
#    fign='_'.join(['pclose','g'+g])+'.png'
#
#    fig=plt.figure(figsize=(800/my_dpi,600/my_dpi),dpi=my_dpi)
#    ax=fig.add_axes(rect)
#    ax.set_title(r'$P_{close}\ pre7=$'+g)
#    ax.set_xlabel(r'$[AMP](\mu M)$')
#    ax.set_ylabel(r'$P_{close}$')
#
#    for n,pclose in enumerate(pcloselist):
#        dv=dvlist[n]
#        for i in atpconc:
#
#            fn='_'.join(['turnover','dv'+dv,'g'+g])+'.dat'
#            data=np.loadtxt(fn,comments="# @".split())
#            x=data[:,0]
#            y=data[:,3]/tscale
#            pc=data[:,4]
#
#            #ax.plot(x,y,'o-',label=r'$[AMP]=%.0f(\mu M)$'%atp)
#            ax.plot(x,pc,'o--',mfc='none',label='pclose='+pclose)
#        #    ax2.plot(x,p,'o--',color=ax.lines[-1].get_color(),mfc='none')
#
#
#        ax.legend(loc='lower right')
#        fig.savefig(fign)
