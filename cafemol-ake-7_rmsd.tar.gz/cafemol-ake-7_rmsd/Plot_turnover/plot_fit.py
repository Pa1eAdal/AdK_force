# -*- coding: utf-8 -*-
"""
Created on Mon Aug 31 00:02:35 2020

@author: Yang
"""
"""
Mutiple Yaxis With Spines

Create multiple y axes with a shared x axis.
This is done by creating a #twinx axes,
turning all spines but the right one invisible
and offset its position using #set_position.
"""

import numpy as np
import matplotlib.pyplot as plt
import itertools

#from mpl_toolkits.axisartist.parasite_axes import HostAxes,ParasiteAxes
from matplotlib import rc
#plt.rcParams.items()
rc('font',**{'style':'normal','size':8}) # 12
rc('axes',**{'titlesize':8})
rc('mathtext',**{'default':'regular'})
rc(('ytick'),**{'labelsize':6,'direction':'in','major.pad':1,'major.size':3})
rc(('xtick'),**{'labelsize':6,'direction':'in','major.pad':1,'major.size':3})
rc(('axes'),**{'labelsize':8,'labelpad':1,'linewidth':1}) # 10
rc(('legend'),**{'fontsize':6,'frameon':False,'labelspacing':0.5,'handletextpad':0.8}) # 8

cls=plt.rcParams['axes.prop_cycle'].by_key()['color']

def make_patch_spines_invisible(ax):
    ax.set_frame_on(True)
    ax.patch.set_visible(False)
    for sp in ax.spines.values():
        sp.set_visible(False)



pre7="0.41".split()
xkai="0.50 0.75".split()

for g,xk in itertools.product(pre7,xkai):

    fnfit='pclose_kcat_KI_KM_'+g+'_'+xk+'.dat'
    fign='pclose_kcat_KI_KM_'+g+'_'+xk+'.png'
    ##output fitdata:pclose,kcat,KI,KM
    #plist=[float(i) for i in pcloselist]
    #np.savetxt(fnfit,(plist,kcatlist,KIlist,KMlist),fmt='%.2f')

    #plot fit params
    pclose,kcat,kcaterr,KI,KIerr,KM,KMerr=np.loadtxt(fnfit)

    my_dpi=300
    fig,host=plt.subplots(figsize=(2.5,2),dpi=my_dpi)
    fig.subplots_adjust(bottom=0.15,right=0.75)

    par1=host.twinx()
    par2=host.twinx()

    """
    Offset the right spine of par2.
    The ticks and label have already been
    placed on the right by twinx above.
    """
    par2.spines["right"].set_position(("axes",1.2))
    """
    Having been created by twinx,par2 has its frame off,
    so the line of its detached spine is invisible.
    First, activate the frame but make the patch and spines invisible.
    """
    make_patch_spines_invisible(par2)
    """
    Second,show the right spine
    """
    par2.spines["right"].set_visible(True)


    #Pclose kcat KI KM
    host.set_title('$\Delta V$'+'   '+'$\chi_{cut}$=%s' % xk )
    host.set_xlabel(r'$P_{close}$')
    host.set_ylabel(r'$kcat\ (\mu M\ of\ ADP/min/nM\ Adk)$')
    par1.set_ylabel(r'$KI\ (\mu M)$')
    par2.set_ylabel(r'$KM\ (\mu M)$')

    c1,c2=20,80
    i1,i2=200,4200
    m1,m2=0,400
    host.set_ylim(c1,c2)
    par1.set_ylim(i1,i2)
    par2.set_ylim(m1,m2)

    host.set_yticks(np.linspace(c1,c2,5))
    par1.set_yticks(np.linspace(i1,i2,5))
    par2.set_yticks(np.linspace(m1,m2,5))

    ### linear
    host.set_xlim(-0.08,1.08)
    host.set_xticks([0.0,0.2,0.4,0.6,0.8,1.0])
    host.set_xticks([0.1,0.3,0.5,0.7],minor=True)
    host.set_xticklabels('0.0 0.2 0.4 0.6 0.8 1.0'.split())
    
    ### log
    host.set_xscale('log')
    host.set_xlim(0.003*10**(-0.08),1*10**(0.08))

    host.vlines(x=0.283,ymin=0,ymax=1000,linestyle='--',color="grey")

    p1=host.errorbar(pclose,kcat,kcaterr,color=cls[0],capsize=2)
    p2=par1.errorbar(pclose,KI,yerr=KIerr,color=cls[1],capsize=2)
    p3=par2.errorbar(pclose,KM,yerr=KMerr,color=cls[2],capsize=2)

    dot1,=host.plot(0.283,68.6,'o',color=cls[0],ms=4)
    dot2,=par1.plot(0.283,930.5,'o',color=cls[1],ms=4)
    dot3,=par2.plot(0.283,46.8,'o',color=cls[2],ms=4)

    p1,=host.plot(pclose,kcat,color=cls[0],label=r'$k_{cat}$')
    p2,=par1.plot(pclose,KI,color=cls[1],label='KI')
    p3,=par2.plot(pclose,KM,color=cls[2],label='KM')

    host.yaxis.label.set_color(p1.get_color())
    par1.yaxis.label.set_color(p2.get_color())
    par2.yaxis.label.set_color(p3.get_color())

    tkw=dict(size=2,width=1.0)
    host.tick_params(axis='y',colors=p1.get_color(),**tkw)
    par1.tick_params(axis='y',colors=p2.get_color(),**tkw)
    par2.tick_params(axis='y',colors=p3.get_color(),**tkw)
    host.tick_params(axis='x',**tkw)

    lines=[p1,p2,p3]
    host.legend(lines,[l.get_label() for l in lines],ncol=3,\
                loc='upper center',\
                columnspacing=1.0,handletextpad=None,markerscale=0.8)

    plt.show()

    fig.savefig(fign)

