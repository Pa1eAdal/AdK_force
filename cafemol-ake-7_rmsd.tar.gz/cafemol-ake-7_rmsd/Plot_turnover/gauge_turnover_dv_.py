# -*- coding: utf-8 -*-
"""
Created on Mon Aug  3 02:04:06 2020

@author: Yang
"""

import numpy as np
import itertools

dirdata='../workdir/'
# valist=( -5.1 -5.7 -6.3 -4.7 -4.2 -3.8 -3.4 -3.1 -6.9  -7.5 -4.6 -4.5 -4.4  -8.1  -9.7)
# vblist=( -7.9 -8.5 -9.1 -7.3 -6.6 -5.9 -5.3 -4.8 -9.7 -10.3 -7.2 -7.1 -7.0 -10.9 -11.5)
# vclist=( -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0 -5.0  -5.0 -5.0 -5.0 -5.0  -5.0  -5.0)
# dvnlist=(   0    1    2    3    4    5    6    7    8     9   10   11   12    13    14)
# pclose=( 0.30 0.52 0.77 0.15 0.05 0.02 9e-3 3e-3 0.89  0.94 0.12 0.10 0.09 0.986 0.997)

# dvlist,pcloselist=np.loadtxt(dirdata+'pclose-dv.dat',comments='#',usecols=(0,6),unpack=True)
#dvlist="7 10 0 1 2 14".split()
#pcloselist="0.003 0.12 0.30 0.55 0.77 0.997".split()
dvlist="0".split()
pcloselist=[0.283]
pre7="0.41".split()
rmsdlist='1.0 0.9 0.8 0.6'.split()
atpconc="1000".split()
# tscale=49*(10**7)*(10**-12)#ms
tscale = 112/(2e5)
tscalefit = tscale/60
# main
# def main():
for t in atpconc:
    # tscalefit=(float(t)*49*(10**7)*(10**-15)/60.0)#min
    for g,rmsd in itertools.product(pre7,rmsdlist):
        for n,pclose in enumerate(pcloselist):
            pclose='%.3f'%pclose
            print(pclose)
            dv=str(int(dvlist[n]))
        
            fn=dirdata + 'turnover_ave/turnover_dv%s_g%s_r%s.dat' % (dv,g,rmsd)
            print(fn)
            try:
                data=np.loadtxt(fn,comments="# @".split())
            except:
                print("ADD_CALC"+fn)
                continue
            x=data[:,0]
            x=np.array([0]+list(x))
            tmpa=np.zeros(1)
            tmpb=data[:,3]*0.5
            tmp=np.concatenate((tmpa,tmpb))
            y=tmp/tscale
            yout=tmp/tscalefit
            pc3=data[:,4]
            
            # turnover_ms vs ampconc 
            np.savetxt('turnover_%s_%s_%s.dat' % (pclose,g,rmsd), (x,y), fmt='%.8f')
            # V vs ampconc
            np.savetxt('xy_%s_%s_%s.dat' % (pclose,g,rmsd), (x,yout), fmt='%.8f')
            # ADD_CALC : ampconc=0 
            np.savetxt('pc3_%s_%s_%s.dat' % (pclose,g,rmsd), (x[1:],pc3), fmt='%.8f')


# # start
# if __name__ == "__main__":
#     main()
